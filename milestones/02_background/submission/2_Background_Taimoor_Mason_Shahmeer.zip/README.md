# CSC501 Milestone 2: Background and Related Work

Team: Taimoor Shahzad, Mason Li, and M. Shahmeer Ather Kakwan.

Project: Extending the Financial Industry Business Ontology to Represent Time-Varying Exchange-Traded Fund Allocations.

Repository: https://github.com/Pyrex111/CSC501_Data_Modeling_Project

## Submission and build

Open `2_Background.tex` as the main file and compile with pdfLaTeX and BibTeX, or run:

```sh
latexmk -pdf 2_Background.tex
```

Use a recent TeX Live distribution or Overleaf with the required ACM fonts installed. The package includes the unmodified current ACM `acmart.cls` (version 2.20), its bibliography style, and the corresponding class source and licence information in `vendor/acmart/`. The document uses `sigconf,nonacm`.

`2_Background.pdf` contains exactly two pages of text (including authors, the hierarchy figure, comparison table, and references), one full page containing the revised ERD, and twenty pages of original student drafts in the AI-assisted editing appendix:

| PDF pages | Content |
| --- | --- |
| 1–2 | Assessed report text |
| 3 | Revised conceptual ERD |
| 4–9 | Taimoor's contribution draft |
| 10–13 | Mason's supplied second draft |
| 14–21 | Shahmeer's supplied second draft |
| 22–23 | Supplied abstract and introduction draft |

The separate Word document is a review copy with an editable report body and a different page layout. Submit this ZIP containing the ACM LaTeX source and compiled PDF.

## Included sources

`figures/etf_allocation_erd.pdf` and `.drawio` are the revised connector diagram supplied in Taimoor's latest contribution ZIP. The hierarchy figure is accompanied by its Mermaid source.

`original_drafts/` contains the latest four supplied Word drafts, preserved unchanged under normalized filenames, and their PDF renderings. The original drafts are reproduced in the report appendix. Assembly condenses and edits the supplied work for clarity and the required page limit; the appendix retains the students' draft content and notes.

`supporting_notes/` preserves the supplied FIBO evidence, pinned source manifest, and Taimoor's LaTeX and bibliography fragments. These fragments are reference material, not independent build targets. `assembly_sources.json` records the supplied filenames, packaged locations, and SHA-256 hashes of the unchanged input files.

## Individual contributions

The repository link is included in the report. Each member remains responsible for documenting their own substantive contributions through their individual Git account, as required by the milestone manual. Building this package does not establish or verify individual repository contributions.
