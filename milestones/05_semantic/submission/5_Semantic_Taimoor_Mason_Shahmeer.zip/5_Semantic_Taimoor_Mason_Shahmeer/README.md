# Milestone 5 submission

The compiled report is `main.pdf`: exactly three ACM `sigconf` double-column
pages. Author order is retained: Taimoor Shahzad, M. Shahmeer Ather Kakwan,
Mason Li.

## Compile the self-contained source

Use a current LaTeX distribution or Overleaf with the ACM `sigconf` dependencies
(including Libertine, Inconsolata and newtxmath fonts), `xurl` and BibTeX. From
this directory:

```sh
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The ACM class and bibliography style retain their own license notices. All
local sections, bibliography, tables and the required figure PDF are included.

## Report contents

- `main.tex`: title, abstract, introduction, section assembly and the AI
  assistance/evaluation note.
- `mason_ontology_section.tex`: the OWL ontology, FIBO reuse boundary, identity
  and provenance rules, and the OWL-versus-explicit-validator split.
- `taimoor_semantic_section.tex`: embedded Oxigraph store, SPARQL/SQL parity,
  staged-write validation and reproducibility.
- `shahmeer_ui_semantic_section.tex`: the graph-backed Flask interface, shared
  validated graph instance, translated validator messages and UI tests.
- `tables/`: the FIBO alignment table and the OWL/explicit rule split table.
- `figures/system_architecture_m5.pdf`: committed M5 layer diagram (Flask UI,
  business helpers, graph data access with validation before publish, embedded
  Oxigraph store with separate ontology and data named graphs).
- `supplements/ui_screenshots/`: all eleven full-resolution UI captures,
  including search, detail, create, batch update, delete, rejected writes and
  the dated portfolio view. Their pixels match the repository originals.

## Evidence and implementation

The 189-test suite, ontology file, graph validator, backend hook, SPARQL
queries, seed data and per-member AI-use/evaluation records are in the linked
repository:
https://github.com/Pyrex111/CSC501_Data_Modeling_Project

Run `python -m pip install -r requirements-semantic.txt`, then
`python quickstart_semantic.py --serve` from a checkout. All demonstration
records are fictional; no real customer, fund or source document is used.
