# Milestone 5 submission

main.pdf is the compiled three-page ACM sigconf report. All demonstration data
are synthetic. The package includes the exact report sources, executable SPARQL
example, architecture PDF/PNG/DOT files and eleven original UI screenshots.
MANIFEST.json records SHA-256 checksums of every other packaged file.

## Compile

Use a LaTeX distribution with the ACM sigconf dependencies (Libertine,
Inconsolata and newtxmath), xurl, pdflatex and BibTeX. From this directory:

    pdflatex -interaction=nonstopmode -halt-on-error main.tex
    bibtex main
    pdflatex -interaction=nonstopmode -halt-on-error main.tex
    pdflatex -interaction=nonstopmode -halt-on-error main.tex

Check that the rebuilt PDF remains exactly three pages. The figure is in figures/
and the displayed query is read from examples/taimoor_snapshot_totals.sparql.
ACM class/style and third-party software retain their original license notices.

## Application and verification

https://github.com/Pyrex111/CSC501_Data_Modeling_Project

From a checkout, install requirements-semantic.txt and run:

    python quickstart_semantic.py --compare
    python quickstart_semantic.py --serve
    python -m unittest discover -s tests -q

Stop the server before opening the same persistent store in another process.
The report credits both ChatGPT/Codex and Claude. Automated checks are
assistant-executed; student design review is recorded separately.
